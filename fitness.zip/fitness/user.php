<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Fitness - Admin</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/fitness.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- jQuery -->
    <script src="js/jquery.js"></script>
    <script type="text/javascript" src="js/function.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">

</head>

<body>
        
    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Fitness Hub</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="#">About</a>
                    </li>
                    <li>
                        <a href="#">Services</a>
                    </li>
                    <li>
                        <a href="#">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <div class="col-md-3">
                <p class="lead">Manage</p>
                <div class="list-group">
                    <a href="index.php" class="list-group-item">Dashboard</a>
                    <a href="user.php" class="list-group-item active">User's List</a>
                    <a href="plan.php" class="list-group-item">Plan's List</a>
                    <a href="assign.php" class="list-group-item">Assign Plan's</a>
                </div>
            </div>

            <div class="col-md-9">

             <h2>User List</h2><span class="pull-right"><button id="createuser" type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal" title="Add User"><span class="glyphicon glyphicon-plus"></span> Add User</button></span>
              

            
		  <table class="table">
		    <thead>
		      <tr>
			<th>Firstname</th>
			<th>Lastname</th>
			<th>Email</th>
                        <th></th>
		      </tr>
		    </thead>
		    <tbody id="users">
		      
		    </tbody>
		  </table>

           </div>
<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add User</h4>
        </div>
        <div class="modal-body">
                 <form action="api/api.php?method=create_user&api_key=82833" method="post" id="userform" data-autosubmit>
		  <div class="form-group">
		    <label for="email">First name:</label>
		    <input type="text" class="form-control" id="email" name="first_name">
		  </div>
		  <div class="form-group">
		    <label for="email">Last name:</label>
		    <input type="text" class="form-control" id="email" name="last_name">
		  </div>
		  <div class="form-group">
		    <label for="email">E-mail:</label>
		    <input type="email" class="form-control" id="email" name="email">
		  </div>
		  <button type="submit" class="btn btn-default" >Submit</button>
		</form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

        <!-- Modal -->
  <div class="modal fade" id="editform" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Update User</h4>
        </div>
        <div class="modal-body">
              
		  <div class="form-group">
		    <label for="email">First name:</label>
		    <input type="text" class="form-control" id="update_first_name" name="first_name" value="">
		  </div>
		  <div class="form-group">
		    <label for="email">Last name:</label>
		    <input type="text" class="form-control" id="update_last_name" name="last_name" value="">
		  </div>
		  <div class="form-group">
		    <label for="email">E-mail:</label>
		    <input type="email" class="form-control" id="update_email" name="email" value="">
		  </div>
                   <input type="hidden" id="hidden_user_id">
		  <button type="submit" class="btn btn-default" onclick="UpdateUserDetails() ">Submit</button>
		 
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>
     </div>
    <!-- /.container -->

    <div class="container">
	

        <hr>

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                   <center> <p>Copyright &copy; Fitness Co. Developed by AZAM</p></center>
                </div>
            </div>
        </footer>

    </div>
    <!-- /.container -->

    

</body>

</html>
