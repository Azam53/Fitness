<html>
<head>
</head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
<script>
      
         $(function(){
              $.getJSON("api.php?method=get_user&api_key=82833&jsoncallback=?" ,
                  function(data){
                      for(aUser in data){
                        var user = data[aUser];
                         console.log(user.first_name + ' ' + user.last_name);
                       }
                  });
         });
</script>
<body>
      
       <form action="api.php?method=create_user" method="post">
  <div class="form-group">
    <label for="email">First name:</label>
    <input type="text" class="form-control" id="email" name="first_name">
  </div>
  <div class="form-group">
    <label for="email">Last name:</label>
    <input type="text" class="form-control" id="email" name="last_name">
  </div>
  <div class="form-group">
    <label for="email">E-mail:</label>
    <input type="email" class="form-control" id="email" name="email">
  </div>
  <button type="submit" class="btn btn-default">Submit</button>
</form>
</body>
</html>

