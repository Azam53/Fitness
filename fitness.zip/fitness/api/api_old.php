<?php

// Connect to database

     mysql_connect("localhost","root","root") or die(mysql_error());
     mysql_select_db("fitness") or die(mysql_error());

// api key validation for security and to put limit on using

     $api_key = "82833";

            if( $api_key != $_GET['api_key']){
                
               die("Authentication Problem");
            }
 
//call the passed in function....
            
            if(function_exists($_GET['method'])) {
                
                  $_GET['method']();
            }
            else{
                  
                  echo "Bad Request ";
            }


// methods for get user

   function get_user(){
        
            
         $user_sql = mysql_query("SELECT * from users");
         $users = array();
                
                  while( $user = mysql_fetch_array($user_sql)){
                           $users[] = $user;
                  }
                  
                  $users = json_encode($users);
                  echo $_GET['jsoncallback']. '('. $users . ')';
               
 
   }

   function create_user(){
        
         $firstname = mysql_real_escape_string($_POST['first_name']);
         $lastname = mysql_real_escape_string($_POST['last_name']);
         $email = mysql_real_escape_string($_POST['email']);  
          
         $user_sql = mysql_query("INSERT INTO users(first_name,last_name,email) values('$firstname','$lastname','$email')");
                
                   if(!$user_sql){
                    
                      die(mysql_error());
 
                   }
                   else{
                    
                      echo "Record added Successfully"; 
                           
                   }
                   
   }
  
   function delete_user(){
        
         $id = $_GET['u_id'];
          
         $user_sql = mysql_query("DELETE FROM users WHERE id='$id'");
                
                   if(!$user_sql){
                    
                      die(mysql_error());
 
                   }
                   else{
                    
                      echo "Record deleted Successfully"; 
                           
                   }
                   
   }

   function update_user(){
        
         $id = $_GET['u_id'];
         $firstname = $_GET['first'];
         $lastname = $_GET['last'];
         $email = $_GET['email'];
          
         $user_sql = mysql_query("UPDATE  users SET first_name='$firstname',last_name='$lastname',email='$email'  WHERE id='$id'");
                
                   if(!$user_sql){
                    
                      die(mysql_error());
 
                   }
                   else{
                    
                      echo "Record updated Successfully"; 
                           
                   }
                   
   }


?>
