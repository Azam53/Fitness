<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Fitness - Admin</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/fitness.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- jQuery -->
    <script src="js/jquery.js"></script>
    <script type="text/javascript" src="js/function.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">

</head>

<body>
        
    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Fitness Hub</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="#">About</a>
                    </li>
                    <li>
                        <a href="#">Services</a>
                    </li>
                    <li>
                        <a href="#">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <div class="col-md-3">
                <p class="lead">Manage</p>
                <div class="list-group">
                    <a href="index.php" class="list-group-item">Dashboard</a>
                    <a href="user.php" class="list-group-item">User's List</a>
                    <a href="plan.php" class="list-group-item">Plan's List</a>
                    <a href="assign.php" class="list-group-item active">Assign Plan's</a>
                </div>
            </div>

            <div class="col-md-9">

             <h2>Assign Plan to User</h2>
          <div class="alert alert-success" style="display:none;" id="success">
                 <strong>Success!</strong> The user is assign to the selected Plan.
          </div>
  
    <div class="form-group">
      <label for="email">Plan:</label>
      <select class="form-control" id="planselect" name="plan">
    </select>
    </div>
    <div class="form-group">
      <label for="pwd">User:</label>
      <select class="form-control" id="userselect" name="user">
    </select>
    </div>
    
    <button type="submit" class="btn btn-primary" onclick="UpdatePlanMember()">Submit</button>
  


           </div>

  
</div>
     </div>
    <!-- /.container -->

    <div class="container">
	

        <hr>

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                   <center> <p>Copyright &copy; Fitness Co. Developed by AZAM</p></center>
                </div>
            </div>
        </footer>

    </div>
    <!-- /.container -->

    

</body>

</html>
