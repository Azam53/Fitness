<?php

// Connect to database

     mysql_connect("localhost","root","root") or die(mysql_error());
     mysql_select_db("fitness") or die(mysql_error());

// api key validation for security and to put limit on using

     $api_key = "82833";

            if( $api_key != $_GET['api_key']){
                
               die("Authentication Problem");
            }
 
//call the passed in function....
            
            if(function_exists($_GET['method'])) {
                
                  $_GET['method']();
            }
            else{
                  
                  echo "Bad Request ";
            }


// methods for get user

   function get_user(){
        
            
         $user_sql = mysql_query("SELECT id,first_name,last_name,email from users");
         $users = array();
                
                  while( $user = mysql_fetch_array($user_sql)){
                           $users[] = $user;
                  }
                  
                  $users = json_encode($users);
                 echo $_GET['jsoncallback']. '('. $users . ')';
                  
 
   }

   function create_user(){
        
         $firstname = mysql_real_escape_string($_POST['first_name']);
         $lastname = mysql_real_escape_string($_POST['last_name']);
         $email = mysql_real_escape_string($_POST['email']); 
  
          if(empty($firstname) || empty($lastname) || empty($email)){
              
                  die("Properly fill the form input");
           } 
          
         $user_sql = mysql_query("INSERT INTO users(first_name,last_name,email) values('$firstname','$lastname','$email')");
                
                   if(!$user_sql){
                    
                      die(mysql_error());
 
                   }
                   else{
                    
                      echo "Record added Successfully";
                           
                   }
                   
   }
  
   function delete_user(){
        
         $id = $_GET['u_id'];
          
         $user_sql = mysql_query("DELETE FROM users WHERE id='$id'");
                
                   if(!$user_sql){
                    
                      die(mysql_error());
 
                   }
                   else{
                    
                      echo "Record deleted Successfully"; 
                           
                   }
                   
   }

   function update_user(){
        
         $id = $_POST['id'];
         $firstname = $_POST['first'];
         $lastname = $_POST['last'];
         $email = $_POST['email'];
       
          
         $user_sql = mysql_query("UPDATE  users SET first_name='$firstname',last_name='$lastname',email='$email'  WHERE id='$id'");
                
                   if(!$user_sql){
                    
                      die(mysql_error());
 
                   }
                   else{
                    
                      echo "Record updated Successfully"; 
                           
                   }
                   
   }

   function get_user_id(){
			if(isset($_POST['user_id']) && isset($_POST['user_id']) != "")
		{
		    // get User ID
		    $user_id = $_POST['user_id'];
		
		    // Get User Details
		    $query = "SELECT * FROM users WHERE id = '$user_id'";
		    if (!$result = mysql_query($query)) {
			exit(mysqli_error($con));
		    }
		    $response = array();
		    if(mysql_num_rows($result) > 0) {
			while ($row = mysql_fetch_assoc($result)) {
			    $response = $row;
			}
		    }
		    else
		    {
			$response['status'] = 200;
			$response['message'] = "Data not found!";
		    }
		    // display JSON data
		    echo json_encode($response);
		}
		else
		{
		    $response['status'] = 200;
		    $response['message'] = "Invalid Request!";
		   }

       }

 // method for get plan

   function get_plan(){
        
            
         $plan_sql = mysql_query("SELECT * from plan");
         $plans = array();
                
                  while( $plan = mysql_fetch_array($plan_sql)){
                           $plans[] = $plan;
                  }
                  
                  $plans = json_encode($plans);
                 echo $_GET['jsoncallback2']. '('. $plans . ')';
                  
 
   }

?>
