<?php

// Connect to database

     mysql_connect("localhost","root","") or die(mysql_error());
     mysql_select_db("fitness") or die(mysql_error());
?>