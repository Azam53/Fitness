$(function(){
              $.getJSON("api/api.php?method=get_user&api_key=82833&jsoncallback=?" ,
                  function(data){
                     var peopleHTML = "";
                      for(aUser in data){
                        var user = data[aUser];
                         //console.log(user.first_name + ' ' + user.last_name);
		            peopleHTML += "<tr>";
                            //peopleHTML += "<td style='display:none'>" + user.id + "</td>";
			    peopleHTML += "<td>" + user.first_name + "</td>";
			    peopleHTML += "<td>" + user.last_name + "</td>";
			    peopleHTML += "<td>" + user.email + "</td>";
                            peopleHTML += "<td><button class='btn btn-success btn-xs' title='delete' onclick='ask_to_edit_user("+ user.id + ")'><i class='icon-fixed-width icon-pencil'></i>Edit</button></td>";
                            peopleHTML += "<td><button class='btn btn-danger btn-xs' title='delete' onclick='ask_to_delete_user("+ user.id + ")'><i class='icon-trash'></i> Delete</button></td>";
			    peopleHTML += "</tr>";
                       }
                        $("#users").append(peopleHTML);
                       
                  });
             $.getJSON("api/api.php?method=get_plan&api_key=82833&jsoncallback2=?" ,
                  function(response){ 
                     var planHTML = "";
                      for(aUser in response){
                        var plan = response[aUser];
                         //console.log(user.first_name + ' ' + user.last_name);
		            planHTML += "<tr>";
                            //peopleHTML += "<td style='display:none'>" + user.id + "</td>";
			    planHTML += "<td>" + plan.plan_name + "</td>";
			    planHTML += "<td>" + plan.days + "</td>";
			    planHTML += "<td>" + plan.exercises + "</td>";
                            planHTML += "<td><button class='btn btn-success btn-xs' title='delete' onclick='ask_to_edit_plan("+ plan.id + ")'><i class='icon-fixed-width icon-pencil'></i>Edit</button></td>";
                            planHTML += "<td><button class='btn btn-danger btn-xs' title='delete' onclick='ask_to_delete_plan("+ plan.id + ")'><i class='icon-trash'></i> Delete</button></td>";
			    planHTML += "</tr>";
                       }
                        $("#plans").append(planHTML);
                       
                  });           
         });

// function to delete user on press of icon from user list
function ask_to_delete_user(id){
     var user_id = id;
     if(confirm("Are you Sure!!!"))
     {
        $.ajax({
                type: "GET",
                url: "api/api.php?method=delete_user&api_key=82833" ,
                data: { u_id: user_id },
                success : function() { 


                    // function below reloads current page
                    location.reload();

                }
            });
     }
     else
     {
         location.reload();
     }
}

// insert user js autocomplete for 
$(function() {
  $('form[data-autosubmit]').autosubmit();
});

(function($) {
  $.fn.autosubmit = function() {
    this.submit(function(event) {
      event.preventDefault();
      var form = $(this);
      $.ajax({
        type: form.attr('method'),
        url: form.attr('action'),
        data: form.serialize()
      }).done(function(data) {
          location.reload();
      }).fail(function(data) {
          console.log("Not inserted");
      });
    });
    return this;
  }
})(jQuery)

// edit user function
function ask_to_edit_user(id){
     var user_id = id;
     $.post("api/api.php?method=get_user_id&api_key=82833", {
            user_id: user_id
        },
     function (data, status) {
            // PARSE json data
            
            var user = JSON.parse(data);
            $("#update_first_name").val(user.first_name);
            $("#update_last_name").val(user.last_name);
            $("#update_email").val(user.email);
            $("#hidden_user_id").val(user.id);
            
        }
    );
    // Open modal popup
    $("#editform").modal("show");
    
}

// function for updating user
function UpdateUserDetails() {
    // get values
    var first_name = $("#update_first_name").val();
    var last_name = $("#update_last_name").val();
    var email = $("#update_email").val();
 
    // get hidden field value
    var id = $("#hidden_user_id").val();
 
    // Update the details by requesting to the server using ajax
    $.post("api/api.php?method=update_user&api_key=82833", {
            id: id,
            first: first_name,
            last: last_name,
            email: email
        },
        function (data, status) {
            // hide modal popup
             location.reload();
        }
    );
}

 

// insert plan js autocomplete for 
$(function() {
  $('form[dataplan-autosubmit]').autosubmit();
});

(function($) {
  $.fn.autosubmit = function() {
    this.submit(function(event) {
      event.preventDefault();
      var form = $(this);
      $.ajax({
        type: form.attr('method'),
        url: form.attr('action'),
        data: form.serialize()
      }).done(function(data) {
          console.log(data);
          location.reload();
      }).fail(function(data) {
          console.log("Not inserted");
      });
    });
    return this;
  }
})(jQuery)


// function to delete plan on press of icon from user list
function ask_to_delete_plan(id){
     var p_id = id;
     if(confirm("Are you Sure!!!"))
     {
        $.ajax({
                type: "GET",
                url: "api/api.php?method=delete_plan&api_key=82833" ,
                data: { p_id: p_id },
                success : function() { 


                    // function below reloads current page
                    location.reload();

                }
            });
     }
     else
     {
         location.reload();
     }
}

// edit plan function
function ask_to_edit_plan(id){
     var p_id = id;
     $.post("api/api.php?method=get_plan_id&api_key=82833", {
            p_id: p_id
        },
     function (data, status) {
            // PARSE json data
            console.log(data);
            var user = JSON.parse(data);
            $("#update_plan_name").val(user.plan_name);
            $("#update_days").val(user.days);
            $("#update_exercises").val(user.exercises);
            $("#update_duration").val(user.duration);
            $("#hidden_plan_id").val(user.id);
            
        }
    );
    // Open modal popup
    $("#editplan").modal("show");
    
}

// function for updating user
function UpdatePlanDetails() {
    // get values
    var plan_name = $("#update_plan_name").val();
    var days = $("#update_days").val();
    var exercises = $("#update_exercises").val();
    var duration = $("#update_duration").val();
 
    // get hidden field value
    var id = $("#hidden_plan_id").val();
 
    // Update the details by requesting to the server using ajax
    $.post("api/api.php?method=update_plan&api_key=82833", {
            id: id,
            plan_name: plan_name,
            days: days,
            exercises: exercises,
            duration:duration
        },
        function (data, status) {
            
             location.reload();
        }
    );
}

$(function(){
              $.getJSON("api/api.php?method=get_user&api_key=82833&jsoncallback=?" ,
                  function(data){
                     var userHTML = "";
                      for(aUser in data){
                        var user = data[aUser];
                         //console.log(user.first_name + ' ' + user.last_name);
                            
			    userHTML += "<option value=" + user.id + " >" + user.first_name + ' ' + user.last_name + "</option>";
			    
                       }
                        $("#userselect").append(userHTML);
                       
                  });
        
              $.getJSON("api/api.php?method=get_plan&api_key=82833&jsoncallback2=?" ,
                  function(data){
                     var planHTML = "";
                      for(aplan in data){
                        var plan = data[aplan];
                         //console.log(user.first_name + ' ' + user.last_name);
                            
			    planHTML += "<option value=" + plan.id + " >" + plan.plan_name + "</option>";
			    
                       }
                        $("#planselect").append(planHTML);
                       
                  });

});

// function for assigning user in particular plan
function UpdatePlanMember() {
    // get values
    var plan_id = $("#planselect").val();
    var user_id = $("#userselect").val();
    
 
    // Update the details by requesting to the server using ajax
    $.post("api/api.php?method=insert_member&api_key=82833", {
            id: plan_id,
            member: user_id
        },
        function (data, status) {
             $('#success').show();
              location.reload();
             
        }
    );
}


